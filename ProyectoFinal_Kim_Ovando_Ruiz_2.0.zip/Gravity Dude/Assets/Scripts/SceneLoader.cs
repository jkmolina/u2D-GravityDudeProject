﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


// Script used to load different scenes on button presses and the pause menu
public class SceneLoader : MonoBehaviour
{
    private bool isPaused = false;
    public GameObject pauseMenu;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            MyPause();
        }
    }

    public void MyPause()
    {
        // Changes the time scale to zero if paused; instances or removes the visibility of the menu
        if (isPaused)
        {
            if (pauseMenu) pauseMenu.SetActive(false);
            Time.timeScale = 1.0f;
        }

        else
        {
            if (pauseMenu) pauseMenu.SetActive(true);
            Time.timeScale = 0.0f;
        }

        isPaused = !isPaused;
    }


    // Functions that load scenes
    public void continueGame()
    {
        MyPause();
    }
    public void mainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void controls()
    {
        SceneManager.LoadScene("Controls");
    }

    public void level1()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("SampleScene");
    }

    public void exitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;

#else
        Application.Quit();
#endif 
    }

}
