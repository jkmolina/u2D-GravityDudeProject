﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class WinObject : MonoBehaviour
{
    // Limits framerate to avoid blurry images
    void Awake()
    {
        QualitySettings.vSyncCount = 0;  // VSync must be disabled
        Application.targetFrameRate = 60;
    }
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        // This detects if player 1 or player 2 wins once one of them reaches the end
        if (collision.CompareTag("Player1"))
        {
            Debug.Log("Player 1 Wins!");
            SceneManager.LoadScene("Player1Wins");
            Destroy(collision.gameObject);
            //load scene
        }
        if (collision.CompareTag("Player2"))
        {
            Debug.Log("Player 2 Wins!");
            SceneManager.LoadScene("Player2Wins");
            Destroy(collision.gameObject);
            //load scene
        }
    }
}
