﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObject : MonoBehaviour
{
    // Start is called before the first frame update
    public int speed;

    // Update is called once per frame
    void Update()
    {
        // Used to move the main camera
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }
}
