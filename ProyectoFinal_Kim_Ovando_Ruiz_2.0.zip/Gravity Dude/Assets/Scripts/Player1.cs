﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1 : MonoBehaviour
{
    public int hp = 100;
    public GameObject jugador1;
    public int xPosition;
    public int yPosition;
    public float xspeed;
    public float yspeed;
    public Rigidbody2D rb;
    Vector2 pos;
    public bool isGrounded;
    public bool touchesEnemy;

    void Start()
    {
        Vector2 pos = transform.position;

    }

    // Update is called once per frame
    void Update()
    {
        if(Time.timeScale > 0)
        {
            // Adds speed to the player
            Vector3 tempScale = transform.localScale;
            GetComponent<Rigidbody2D>().velocity = new Vector2(xspeed, yspeed);

            // Allows gravity changes
            if (isGrounded && Input.GetKeyDown(KeyCode.A))
            {
                changeYourGravity();
            }
            if (touchesEnemy && Input.GetKeyDown(KeyCode.S))
            {
                changeOtherGravity();
            }
            tempScale.y = (yspeed < 0) ? Mathf.Abs(tempScale.y) : -Mathf.Abs(tempScale.y);
            transform.localScale = tempScale;
        }
    }
    public void TakeDamage(int amount)
    {
        // For a future update where players can take damage
        // hp -= amount;
        if (hp <= 0)
        {
            //Destroy(gameObject);
            pos.x = xPosition;
            pos.y = yPosition;
            transform.position = pos;
        }
    }

    // Changes your gravity
    public void changeYourGravity()
    {
            yspeed = -yspeed;
    }


    // Changes the other player's gravity
    public void changeOtherGravity() {
            GameObject.FindGameObjectWithTag("Player2").GetComponent<Player2>().yspeed *= -1;
    }


    // Collision detection allows to ground, unground, or add speed to the player
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Platform") || collision.gameObject.CompareTag("Block"))
        {
            isGrounded = true;
        }

        if (collision.gameObject.CompareTag("Player2"))
        {
            touchesEnemy = true;
            isGrounded = true;
        }
        if (collision.gameObject.CompareTag("Speed"))
        {
            touchesEnemy = true;
            isGrounded = true;
            xspeed *= 2;
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Platform"))
        {
            isGrounded = false;
        }
        if (collision.gameObject.CompareTag("Player2"))
        {
            touchesEnemy = false;
            //isGrounded = false;
        }
        if (collision.gameObject.CompareTag("Speed"))
        {
            touchesEnemy = true;
            isGrounded = true;
            xspeed /= 2;
        }

    }

}
