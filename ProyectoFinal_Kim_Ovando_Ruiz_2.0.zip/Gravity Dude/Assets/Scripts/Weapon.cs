﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public string fireButton;
    public Transform firePoint;
    public GameObject bulletPrefab;
    public AudioSource laser;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown(fireButton) && Time.timeScale > 0)
        {
            Shoot();
        }
    }

    // Instances the bullet and plays the shooting sound 
    void Shoot()
    {
        Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        laser.Play();
    }
}
